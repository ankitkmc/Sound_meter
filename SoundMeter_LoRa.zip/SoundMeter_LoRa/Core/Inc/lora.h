/*
 * LoRa_HAT.h
 *
 *  Created on: Sep 9, 2025
 *      Author: devesh.sehgal
 */

#ifndef INC_LORA_H_
#define INC_LORA_H_

#include <stdint.h>
#include <string.h>
#include "main.h"


#define CFG_REGISTER												0x01
#define NORMAL_STATUS												0x02
#define WOR_STATUS													0x03
#define SLEEP_STATUS												0x04

#define TRANSPARENT_MODE											0x02
#define RELAY_MODE													0x03
#define WOR_TRANSMISSION_MODE										0x04

#define MAX_BYTES													240
#define PACKET_LENGTH												16

#define CFG_HEADER													0xC0
#define CFG_RETURN													0xC1
#define REG_START													0x00
#define REG_NUMBER													0x09

/********************DEAFULT REGISTER VALUE********************/
#define DEFAULT_ADDH_VALUE											0x00
#define DEFAULT_ADDL_VALUE											0x00
#define DEFAULT_NETID_VALUE											0x00
#define DEFAULT_SERIAL_VALUE										0x62
#define DEFAULT_POWER_VALUE											0x00
#define DEFAULT_CHANNEL_VALUE										0x17
#define DEFAULT_TRANSIMISSION_VALUE									0x03
#define DEFAULT_CRYPTH_VALUE										0x00
#define DEFAULT_CRYPTL_VALUE										0x00

//#define TRANSPARENT_BROADCAST
#define TRANSPARENT_P2P

/********************BROADCAST AND MONITOR REGISTER VALUE********************/
#ifdef 	TRANSPARENT_BROADCAST
#define BROADCAST_ADDH_VALUE										0xFF
#define BROADCAST_ADDL_VALUE 										0xFF
#elif defined TRANSPARENT_P2P
#define BROADCAST_ADDH_VALUE										0x00
#define BROADCAST_ADDL_VALUE										0x00
#endif
#define BROADCAST_NETID_VALUE										0x00
#define BROADCAST_SERIAL_VALUE										0x67
#define BROADCAST_POWER_VALUE										0x00
#define BROADCAST_CHANNEL_VALUE										0x12
#define BROADCAST_TRANSIMISSION_VALUE								0x03
#define BROADCAST_CRYPTH_VALUE										0x00
#define BROADCAST_CRYPTL_VALUE										0x00

/********************RELAY REGISTER VALUE********************/
#define RELAY_ADDH_VALUE											0x00
#define RELAY_ADDL_VALUE 											0x00
#define RELAY_NETID_VALUE											0x01
#define RELAY_SERIAL_VALUE											0x62
#define RELAY_POWER_VALUE											0x00
#define RELAY_CHANNEL_VALUE											0x17
#define RELAY_TRANSIMISSION_VALUE									0x03
#define RELAY_CRYPTH_VALUE											0x00
#define RELAY_CRYPTL_VALUE											0x00

/********************WOR REGISTER VALUE********************/
#define WOR_ADDH_VALUE												0x00
#define WOR_ADDL_VALUE 												0x00
#define WOR_NETID_VALUE												0x00
#define WOR_SERIAL_VALUE											0x62
#define WOR_POWER_VALUE												0x00
#define WOR_CHANNEL_VALUE											0x17
#define WOR_TRANSIMISSION_VALUE										0x0b
#define WOR_CRYPTH_VALUE											0x00
#define WOR_CRYPTL_VALUE											0x00

/********************CFG PINS DEFINITIONS********************/
#define M0_SET()				HAL_GPIO_WritePin(M0_GPIO_Port, M0_Pin, GPIO_PIN_SET)
#define M0_RESET()				HAL_GPIO_WritePin(M0_GPIO_Port, M0_Pin, GPIO_PIN_RESET)

#define M1_SET()				HAL_GPIO_WritePin(M1_GPIO_Port, M1_Pin, GPIO_PIN_SET)
#define M1_RESET()				HAL_GPIO_WritePin(M1_GPIO_Port, M1_Pin, GPIO_PIN_RESET)

#define LED_ON() 				HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_SET)
#define LED_OFF()				HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_RESET)
#define LED_Toggle()			HAL_GPIO_TogglePin(LED_GPIO_Port, LED_Pin)

/************************************************************/
typedef struct lora_para_t
{
	uint8_t address_high;
	uint8_t address_low;
	uint8_t net_id;
	uint8_t serial;
	uint8_t power;
	uint8_t channel;
	uint8_t transmission_mode;
	uint8_t crypt_high;
	uint8_t crypt_low;
}lora_para_t;

extern lora_para_t default_mode;
extern lora_para_t transparent_mode;
extern lora_para_t wor_mode;
extern lora_para_t relay_mode;

void lora_cfg_io(uint8_t status);
uint8_t lora_cfg_mode(uint8_t mode);
uint8_t lora_write_register(lora_para_t send_data);
uint8_t lora_send(uint8_t *send_data);


#endif /* INC_LORA_H_ */
